import 'package:flutter/material.dart';

const arrayBgColor = [
  Color.fromARGB(255, 207, 40, 241),
  Color.fromARGB(255, 252, 18, 147),
  Color.fromARGB(255, 255, 1, 43),
];

const bgColor = Color.fromARGB(255, 94, 183, 228);
const btnColor = Color.fromARGB(251, 39, 39, 243);
const clickColor = Color.fromARGB(255, 255, 94, 0);
const arrayBtnColor = [
  Color.fromARGB(255, 19, 93, 231),
  Color.fromARGB(255, 255, 81, 0),
  Color.fromARGB(255, 255, 0, 221)
];
